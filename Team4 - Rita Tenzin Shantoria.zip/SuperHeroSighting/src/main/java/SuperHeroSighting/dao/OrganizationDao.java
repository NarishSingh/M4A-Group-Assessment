/*
Created by: Margaret Donin
Date created: 09/27/20
Revised by:
Date revised:
*/

package SuperHeroSighting.dao;

import SuperHeroSighting.controller.CanNotDeleteForeignKey;
import SuperHeroSighting.dto.Organization;
import java.util.List;

public interface OrganizationDao {
    /**
     * 
     * @param organization
     * @return 
     */
    Organization addOrganization(Organization organization);
    
    /**
     *
     * @param id
     * @return
     */
    Organization getOrganizationById(int id);
    
    /**
     * 
     * @param superCharacter
     * @return 
     */
    List <Organization> getOrganizationBySuperId(int superId);

    /**
     *
     * @return
     */
    List <Organization> getAllOrganizations();
    
    /**
     * 
     * @param organization 
     */
    void editOrganization(Organization organization);
    
    /**
     * 
     * @param organization 
     */
    void deleteOrganization(Organization organization) throws CanNotDeleteForeignKey;

}

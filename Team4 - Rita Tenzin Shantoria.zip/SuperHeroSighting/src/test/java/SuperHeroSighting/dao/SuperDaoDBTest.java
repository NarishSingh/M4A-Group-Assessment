/*
Created By: Tenzin Woesel
Date created: 09/27/2020
 */
package SuperHeroSighting.dao;

import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.Organization;
import SuperHeroSighting.dto.Power;
import SuperHeroSighting.dto.Sighting;
import SuperHeroSighting.dto.SuperCharacter;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SuperDaoDBTest {

    @Autowired
    SuperDao superDao;

    @Autowired
    PowerDao powerDao;

    @Autowired
    OrganizationDao organizationDao;

    @Autowired
    SightingDao sightingDao;

    @Autowired
    LocationDao locationDao;

    private Power power;
    private List<Power> powers;
    private SuperCharacter superOne;
    private Location location;
    private List<Organization> organizations;
    List<Organization> organizationsList;

    public SuperDaoDBTest() {
    }

    @BeforeEach
    public void setUp() throws Exception {
        List<SuperCharacter> supers = superDao.getAllSupers();

        for (SuperCharacter s : supers) {
            superDao.deleteSuper(s);
        }

        powers = powerDao.getAllPowers();

        for (Power p : powers) {
            powerDao.deletePowerById(p.getId());
        }

        List<Sighting> sightings = sightingDao.getAllSightings();

        for (Sighting s : sightings) {
            sightingDao.deleteSighting(s);
        }

        organizations = organizationDao.getAllOrganizations();

        for (Organization o : organizations) {
            organizationDao.deleteOrganization(o);
        }

        List<Location> locations = locationDao.getAllLocations();

        for (Location l : locations) {
            locationDao.deleteLocation(l.getId());
        }

        location = new Location();
        location.setName("Atlanta");
        location.setDescription("Hot-lanta");
        location.setStreetAddress("1055 Peach Street");
        location.setCity("Atlanta");
        location.setState("GA");
        location.setZip("35035");
        location.setLatitude(new BigDecimal("40.720870"));
        location.setLongitude(new BigDecimal("-73.843354"));

        location = locationDao.addLocation(location);

        Organization organization = new Organization();
        organization.setName("S.H.I.E.L.D");
        organization.setDescription("Super hero org");
        organization.setPhone("1840123395");
        organization.setLocation(location);

        organization = organizationDao.addOrganization(organization);
        organizationsList = new ArrayList<>();
        organizationsList.add(organization);
        
        power = new Power();
        power.setName("One Punch");
        power = powerDao.addPower(power);

        superOne = new SuperCharacter();
        superOne.setName("Hulk");
        superOne.setDescription("strength.");
        superOne.setPower(power);
        superOne.setOrganizations(organizationsList);
    }

    /**
     * Test of addSuper method, of class SuperDaoDB.
     */
    @Test
    public void testAddAndGetSuper() {

        superOne = superDao.addSuper(superOne);

        SuperCharacter superTwo = superDao.getSuperById(superOne.getId());

        assertNotNull(superOne, "Hulk should not be null.");
        assertNotNull(superTwo, "Hulk should not be null.");
        assertEquals(superOne, superTwo, "Both Super Chracters should be equal.");
    }

    /**
     * Test of getSuperById method, of class SuperDaoDB.
     */
    @Test
    public void testGetAllSupers() {

        superOne = superDao.addSuper(superOne);

        SuperCharacter superTwo = new SuperCharacter();
        superTwo.setName("Superman");
        superTwo.setDescription("strength.");
        superTwo.setPower(power);
        superTwo.setOrganizations(organizationsList);

        superTwo = superDao.addSuper(superTwo);

        List<SuperCharacter> supers = superDao.getAllSupers();

        assertNotNull(supers, "The list should not be null.");
        assertEquals(supers.size(), 2, "The list should only have two items.");
        assertTrue(supers.contains(superOne), "Should contain Hulk.");
        assertTrue(supers.contains(superTwo), "Should contain Superman.");

    }

    /**
     * Test of getSuperByLocation method, of class SuperDaoDB.
     */
    @Test
    public void testGetSuperByLocationId() {
        superOne = superDao.addSuper(superOne);

        Sighting sighting = new Sighting();
        sighting = new Sighting();
        sighting.setLocation(location);
        sighting.setSuperCharacter(superOne);

        sighting = sightingDao.addSighting(sighting);

        List<SuperCharacter> supers = superDao.getSuperByLocationId(location.getId());

        assertNotNull(supers);
        assertEquals(1, supers.size());
        assertTrue(supers.contains(superOne));
    }

    /**
     * Test of getSuperByOrganization method, of class SuperDaoDB.
     */
    @Test
    public void testGetSuperByOrganizationId() {

        location = locationDao.addLocation(location);

        Organization organization = new Organization();
        organization.setName("S.H.I.E.L.D");
        organization.setDescription("Super hero org");
        organization.setPhone("1840123395");
        organization.setLocation(location);

        organization = organizationDao.addOrganization(organization);
        
        organizations = new ArrayList<>();
        organizations.add(organization);
        
        superOne.setOrganizations(organizations);
        
        superOne = superDao.addSuper(superOne);

        List<SuperCharacter> supers = superDao.getSuperByOrganizationId(organization.getId());

        assertNotNull(organization);
        assertNotNull(supers);
        assertTrue(supers.contains(superOne));

    }

    /**
     * Test of editSuper method, of class SuperDaoDB.
     */
    @Test
    public void testEditSuper() {

        superOne = superDao.addSuper(superOne);
        int id = superOne.getId();
        SuperCharacter superTwo = superDao.getSuperById(id);

        superTwo.setName("Green Man");
        superDao.editSuper(superTwo);

        assertNotEquals(superOne, superTwo);
        assertNotNull(superOne);
        assertNotNull(superTwo);

    }
//
//    /**
//     * Test of deleteSuper method, of class SuperDaoDB.
//     */
    @Test
    public void testDeleteSuper() {

        superOne = superDao.addSuper(superOne);
        
        Sighting sighting = new Sighting();
        sighting = new Sighting();
        sighting.setDate(LocalDateTime.MAX);
        sighting.setLocation(location);
        sighting.setSuperCharacter(superOne);

        sighting = sightingDao.addSighting(sighting);   
        System.out.println(sighting);

        SuperCharacter superTwo = new SuperCharacter();
        superTwo.setName("Loki");
        superTwo.setDescription("Deceit");
        superTwo.setPower(power);
        superTwo.setOrganizations(organizationsList);

        superTwo = superDao.addSuper(superTwo);

        superDao.deleteSuper(superOne);

        List<SuperCharacter> supers = superDao.getAllSupers();

        assertNotNull(supers);
        assertTrue(supers.contains(superTwo));
        assertFalse(supers.contains(superOne));
        
    }

}

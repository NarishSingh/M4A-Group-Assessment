/*
Created by:
Date created:
Date revised:
 */
package SuperHeroSighting.controller;

import SuperHeroSighting.dao.LocationDao;
import SuperHeroSighting.dao.OrganizationDao;
import SuperHeroSighting.dao.SuperDao;
import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.Organization;
import SuperHeroSighting.dto.SuperCharacter;
import java.util.ArrayList;
import java.util.HashSet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class OrganizationController {

    @Autowired
    OrganizationDao organizationDao;

    @Autowired
    LocationDao locationDao;

    @Autowired
    SuperDao superDao;

    Set<ConstraintViolation<Organization>> violations = new HashSet<>();

    //create
    @PostMapping("addOrganization")
    public String addOrganization(Organization organization, HttpServletRequest request) {

        String locationId = request.getParameter("locationId");
        String[] superIds = request.getParameterValues("superId");

        organization.setLocation(locationDao.getLocation(Integer.parseInt(locationId)));

        List<SuperCharacter> supers = new ArrayList<>();

        if (superIds != null) {
            for (String superId : superIds) {

                supers.add(superDao.getSuperById(Integer.parseInt(superId)));
            }
            
            organization.setSupers(supers);
        }

        

        Validator validate = Validation.buildDefaultValidatorFactory().getValidator();
        violations = validate.validate(organization);

        if (violations.isEmpty()) {
            organizationDao.addOrganization(organization);
        }

        return "redirect:/organizations";
    }

    //view organizations
    @GetMapping("organizations")
    public String getAllOrganizations(Model model) {

        List<Organization> organizations = organizationDao.getAllOrganizations();
        List<Location> locations = locationDao.getAllLocations();
        List<SuperCharacter> supers = superDao.getAllSupers();

        model.addAttribute("organizations", organizations);
        model.addAttribute("locations", locations);
        model.addAttribute("supercharacters", supers);
        model.addAttribute("errors", violations);
        
        return "organizations";
    }

    //view organization details
    @GetMapping("organizationDetails")
    public String getOrganizationDetails(Integer id, Model model) {
        Organization organization = organizationDao.getOrganizationById(id);
        List<SuperCharacter> supers = superDao.getSuperByOrganizationId(id);
        organization.setSupers(supers);
        model.addAttribute("organization", organization);
        return "organizationDetails";
    }

    //delete
    @GetMapping("deleteOrganization")
    public String deleteOrganization(Organization organization) throws CanNotDeleteForeignKey {
        organizationDao.deleteOrganization(organization);
        return "redirect:/organizations";
    }

    //edit
    @GetMapping("editOrganization")
    public String editOrganization(Integer id, Model model) {
        Organization organization = organizationDao.getOrganizationById(id);
        List<SuperCharacter> supers = superDao.getAllSupers();
        List<Location> locations = locationDao.getAllLocations();

        model.addAttribute("organization", organization);
        model.addAttribute("supercharacters", supers);
        model.addAttribute("locations", locations);
        return "editOrganization";
    }

    @PostMapping("editOrganization")
    public String editOrganization(@Valid @ModelAttribute("organization") Organization organization, BindingResult result, HttpServletRequest request,
            Model model) {
        String locationId = request.getParameter("locationId");
        String[] superIds = request.getParameterValues("superId");

        organization.setLocation(locationDao.getLocation(Integer.parseInt(locationId)));

        List<SuperCharacter> superCharacters = new ArrayList<>();

        if (superIds != null) {
            for (String superId : superIds) {
                superCharacters.add(superDao.getSuperById(Integer.parseInt(superId)));
            }
            organization.setSupers(superCharacters);
        }

        if (result.hasErrors()) {
            model.addAttribute("supercharacters", superDao.getAllSupers());
            model.addAttribute("locations", locationDao.getAllLocations());
            model.addAttribute("organization", organization);
            return "editOrganization";
        }

        organizationDao.editOrganization(organization);

        return "redirect:/organizations";
    }

}

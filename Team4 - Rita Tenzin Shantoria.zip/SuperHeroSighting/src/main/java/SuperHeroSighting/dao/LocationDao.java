/*
Created by: Margaret Donin
Date created: 09/27/20
Revised by: Shantoria Taylor
Date revised: 9/29/20
*/

package SuperHeroSighting.dao;

import SuperHeroSighting.controller.CanNotDeleteForeignKey;
import SuperHeroSighting.dto.Location;
import java.util.List;

public interface LocationDao {

    /**
     * Taking in the location of the super sighting or the super org.
     *
     * @param location
     * @return
     */
    Location addLocation(Location location);

    /**
     *
     * @param id
     * @return
     */
    Location getLocation(int id);

    /**
     *
     * @return
     */
    List<Location> getAllLocations();

    /**
     *
     * @param superId
     * @return
     */
    List<Location> getLocationBySuperId(int superId);

    /**
     *
     * @param location
     */
    void editLocation(Location location);

    /**
     *
     * @param location
     */
    void deleteLocation(Integer id);

}

/*
Created by: Margaret Donin
Date created:
Date revised:
 */
package SuperHeroSighting.controller;

import SuperHeroSighting.dao.LocationDao;
import SuperHeroSighting.dao.SightingDao;
import SuperHeroSighting.dao.SuperDao;
import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.Sighting;
import SuperHeroSighting.dto.SuperCharacter;
import static java.lang.Integer.parseInt;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SightingController {

    @Autowired
    private LocationDao locationDao;

    @Autowired
    private SightingDao sightingDao;

    @Autowired
    private SuperDao superDao;

    @GetMapping("/")
    public String displayTenSightings(Model model) {
        List<Sighting> sightings = sightingDao.getLastTenSightings();
        model.addAttribute("sightings", sightings);
        return "index";
    }

    @GetMapping("sightings")
    public String displaySightings(Model model) {
        List<Sighting> sightings = sightingDao.getAllSightings();
        List<SuperCharacter> supers = superDao.getAllSupers();
        List<Location> locations = locationDao.getAllLocations();

        model.addAttribute("sightings", sightings);
        model.addAttribute("supers", supers);
        model.addAttribute("locations", locations);

        return "sightings";
    }

    @PostMapping("addSighting")
    public String addSighting(Sighting sighting, HttpServletRequest request) {
        String locationString = request.getParameter("locationId");
        String superString = request.getParameter("superId");

        sighting.setLocation(new Location(parseInt(locationString)));
        sighting.setSuperCharacter(new SuperCharacter(parseInt(superString)));

        sightingDao.addSighting(sighting);

        return "redirect:/sightings";
    }

    @GetMapping("detailSighting")
    public String detailSighting(Integer id, Model model) {
        Sighting sighting = sightingDao.getSighting(id);
        model.addAttribute("sighting", sighting);
        return "detailSighting";
    }

    @GetMapping("deleteSighting")
    public String deleteSighting(Integer id) {
        Sighting sighting = sightingDao.getSighting(id);
        sightingDao.deleteSighting(sighting);

        return "redirect:/sightings";
    }

    @GetMapping("sightingByDate")
    public String sightingByDate(Integer year, Integer day, Integer month, HttpServletRequest request, Model model) {
        if (year != null && day != null && month != null) {
            try {
                LocalDate ld = LocalDate.of(year, month, day);

                List<Sighting> sightings = sightingDao.getSightingByDate(ld);
                model.addAttribute("sightings", sightings);

                return "sightingByDate";
            } catch (DateTimeException ex) {
                return "redirect:/sightings";
            }
        } else {
            return "redirect:/sightings";
        }
    }

    @GetMapping("editSighting")
    public String editSighting(Integer id, Model model) {
        Sighting sighting = sightingDao.getSighting(id);
        List<SuperCharacter> supers = superDao.getAllSupers();
        List<Location> locations = locationDao.getAllLocations();

        model.addAttribute("sighting", sighting);
        model.addAttribute("supers", supers);
        model.addAttribute("locations", locations);

        return "editSighting";
    }

    @PostMapping("editSighting")
    public String performEditSighting(Sighting sighting, HttpServletRequest request, Model model) {
        String location = request.getParameter("locationId");
        String superCharacter = request.getParameter("superId");
        String sightingId = request.getParameter("id");

        sighting.setId(parseInt(sightingId));
        sighting.setLocation(new Location(parseInt(location)));
        sighting.setSuperCharacter(new SuperCharacter(parseInt(superCharacter)));

        sightingDao.editSighting(sighting);

        return "redirect:/sightings";
    }

}

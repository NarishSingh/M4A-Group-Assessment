/*
Created by: Margaret Donin
Date created: 09/26/2020
Implemented by: Tenzin Woesel
Date implemented: 09/27/2020
Revised by: Margaret Donin
Notes: minor format changes
 */
package SuperHeroSighting.dao;

import SuperHeroSighting.dao.LocationDaoDB.LocationMapper;
import SuperHeroSighting.dao.OrganizationDaoDB.OrganizationMapper;
import SuperHeroSighting.dao.PowerDaoDB.PowerMapper;
import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.Organization;
import SuperHeroSighting.dto.Power;
import SuperHeroSighting.dto.SuperCharacter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class SuperDaoDB implements SuperDao {

    @Autowired
    JdbcTemplate jdbc;

    @Override
    @Transactional
    public SuperCharacter addSuper(SuperCharacter superCharacter) {
        final String INSERT_SUPERCHARACTER = "INSERT INTO SuperCharacter (name, description, powerId) "
                + "VALUES(?,?,?);";
        jdbc.update(INSERT_SUPERCHARACTER,
                superCharacter.getName(),
                superCharacter.getDescription(),
                superCharacter.getPower().getId());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID();", Integer.class);
        superCharacter.setId(newId);
        
        if (superCharacter.getOrganizations() != null) {
            insertOrganization(superCharacter);
        }
        
        return superCharacter;
    }

    @Override
    public SuperCharacter getSuperById(int superId) {
        try {
            final String SELECT_CHARACTER_BY_ID = "SELECT * FROM supercharacter WHERE superId=?";
            SuperCharacter superCharacter = jdbc.queryForObject(SELECT_CHARACTER_BY_ID, new SuperCharacterMapper(), superId);

            superCharacter.setPower(getPowerForSuperCharacter(superId));
            superCharacter.setOrganizations(getOrganizationForSuper(superId));
            return superCharacter;
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    public List<SuperCharacter> getAllSupers() {
        final String SELECT_ALL_SUPERS = "SELECT * FROM SuperCharacter;";

        List<SuperCharacter> superCharacters = jdbc.query(SELECT_ALL_SUPERS, new SuperCharacterMapper());

        associatePowerAndOrganization(superCharacters);
        return superCharacters;

    }

    @Override
    public List<SuperCharacter> getSuperByLocationId(int locationId) {
        final String SELECT_ALL_SUPERS = "SELECT * "
                + "FROM SuperCharacter sc "
                + "JOIN Sighting s "
                + "     ON sc.superId = s.superId "
                + "WHERE s.locationId = ?;";

        List<SuperCharacter> superCharacters = jdbc.query(SELECT_ALL_SUPERS, new SuperCharacterMapper(), locationId);
        associatePowerAndOrganization(superCharacters);
        return superCharacters;
    }

    @Override
    public List<SuperCharacter> getSuperByOrganizationId(int organizationId) {
        final String SELECT_ALL_SUPERS = "SELECT * "
                + "FROM SuperCharacter sc "
                + "JOIN SuperOrganization so "
                + "     ON sc.superId = so.superId "
                + "WHERE so.organizationId = ?;";

        List<SuperCharacter> superCharacters = jdbc.query(SELECT_ALL_SUPERS, new SuperCharacterMapper(), organizationId);
        associatePowerAndOrganization(superCharacters);
        return superCharacters;
    }

    @Override
    public void editSuper(SuperCharacter superCharacter) {

        final String EDIT_SUPER = "UPDATE supercharacter SET name = ?, description = ? "
                + "WHERE superId = ?";
        jdbc.update(EDIT_SUPER, superCharacter.getName(), superCharacter.getDescription(), superCharacter.getId());
    }

    @Override
    @Transactional
    public void deleteSuper(SuperCharacter superCharacter) {
        int superId = superCharacter.getId();

        final String DELETE_SUPER_SIGHTING = "DELETE FROM SIGHTING WHERE superId = ?;";
        jdbc.update(DELETE_SUPER_SIGHTING, superId);

        final String DELETE_SUPER_Organization = "DELETE FROM SuperOrganization WHERE superId = ?;";
        jdbc.update(DELETE_SUPER_Organization, superId);

        final String DELETE_SUPER = "DELETE FROM SuperCharacter WHERE superId = ?;";
        jdbc.update(DELETE_SUPER, superId);

    }

    ////////////////////////////////////////
    ////////HELPER METHODS
    /**
     * Uses the SuperCharacterPower table and associates organization and
     * superCharacter by getting their ID from the superCharacter passed in.
     *
     * @param superCharacter
     */
    private void insertOrganization(SuperCharacter superCharacter) {
        final String INSERT_SUPER_ORGANIZATION = "INSERT INTO SuperOrganization "
                + "(superId, organizationId) VALUES(?, ?);";
        for (Organization organization : superCharacter.getOrganizations()) {
            jdbc.update(INSERT_SUPER_ORGANIZATION, superCharacter.getId(), organization.getId());
        }
    }

    /**
     * First for each supercharacter, it assigns powers associated to them by
     * superId Then for each supercharacter, it assigns organization associated
     * to them by superId
     *
     * @param superCharacters
     */
    private void associatePowerAndOrganization(List<SuperCharacter> superCharacters) {

        for (SuperCharacter superCharacter : superCharacters) {
            superCharacter.setPower(getPowerForSuperCharacter(superCharacter.getId()));
            superCharacter.setOrganizations(getOrganizationForSuper(superCharacter.getId()));
        }
    }

    /**
     * Selects all the powers from SuperCharacterPower table associated with the
     * given superId
     *
     * @param superId
     * @return List of powers for the selected SuperCharacter
     */
    private Power getPowerForSuperCharacter(int superId) {
        final String SELECT_POWERS_FOR_SUPER = "SELECT p.* FROM power p "
                + "JOIN supercharacter s ON s.powerId = p.powerId "
                + " WHERE s.superId=?";
        return jdbc.queryForObject(SELECT_POWERS_FOR_SUPER, new PowerMapper(), superId);

    }

    /**
     * Selects all the powers from SuperCharacterPower table associated with the
     * given superId
     *
     * @param superId
     * @return List of powers for the selected SuperCharacter
     */
    private List<Organization> getOrganizationForSuper(int superId) {
        final String SELECT_ORGANIZATION_FOR_SUPER
                = "SELECT o.* "
                + "FROM organization o "
                + " JOIN superorganization so "
                + "ON so.organizationId = o.organizationId "
                + "WHERE so.superId = ?;";
        //return jdbc.query(SELECT_ORGANIZATION_FOR_SUPER, new OrganizationMapper(), superId);

        List<Organization> organizations = jdbc.query(SELECT_ORGANIZATION_FOR_SUPER, new OrganizationMapper(), superId);
        for (Organization organization : organizations) {
            //insert code here to get the location for the organization.

            final String SELECT_LOCATION_FOR_ORG = "SELECT l.* FROM Location l"
                    + " JOIN organization o ON o.locationId = l.locationId WHERE o.organizationId=? ";
            Location location = jdbc.queryForObject(SELECT_LOCATION_FOR_ORG, new LocationMapper(), organization.getId());
            //then add the location in the organization.
            if (location != null) {
                organization.setLocation(location);
            }

        }
        //then finally return the organization.
        return organizations;


    }
    

    ///////////////////////////////////////////////////
    ////MAPPER
    protected static final class SuperCharacterMapper implements RowMapper<SuperCharacter> {

        @Override
        public SuperCharacter mapRow(ResultSet rs, int index) throws SQLException {
            SuperCharacter superCharacter = new SuperCharacter();
            superCharacter.setId(rs.getInt("superId"));
            superCharacter.setName(rs.getString("name"));
            superCharacter.setDescription(rs.getString("description"));
            return superCharacter;
        }
    }
}

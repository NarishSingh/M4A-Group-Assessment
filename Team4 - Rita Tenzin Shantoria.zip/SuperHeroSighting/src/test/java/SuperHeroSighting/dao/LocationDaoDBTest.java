package SuperHeroSighting.dao;

import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.Organization;
import SuperHeroSighting.dto.Power;
import SuperHeroSighting.dto.Sighting;
import SuperHeroSighting.dto.SuperCharacter;
import java.math.BigDecimal;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 * @author Shantoria Taylor , Sep 30, 2020 , 6:37:39 PM
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class LocationDaoDBTest {

    @Autowired
    private LocationDao locationDao;

    @Autowired
    private OrganizationDao organizationDao;
    
    @Autowired
    private PowerDao powerDao;

    @Autowired
    private SightingDao sightingDao;

    @Autowired
    private SuperDao superDao;

    private SuperCharacter superHero;
    private Power power;
    private Location locationOne;
    private Sighting sightingOne;

    @BeforeEach
    public void setUpClass() throws Exception {

        List<SuperCharacter> supers = superDao.getAllSupers();

        for (SuperCharacter s : supers) {
            superDao.deleteSuper(s);
        }

        List<Power> powers = powerDao.getAllPowers();

        for (Power p : powers) {
            powerDao.deletePowerById(p.getId());
        }

        List<Sighting> sightings = sightingDao.getAllSightings();

        for (Sighting s : sightings) {
            sightingDao.deleteSighting(s);
        }
        
        List<Organization> organizations = organizationDao.getAllOrganizations();
        
        for (Organization o: organizations) {
            organizationDao.deleteOrganization(o);
        }
        

        List<Location> locations = locationDao.getAllLocations();
        
        for (Location l : locations) {
            locationDao.deleteLocation(l.getId());
        }
        
        locationOne = new Location();
        locationOne.setName("Atlanta");
        locationOne.setDescription("Hot-lanta");
        locationOne.setStreetAddress("1055 Peach Street");
        locationOne.setCity("Atlanta");
        locationOne.setState("GA");
        locationOne.setZip("35035");
        locationOne.setLatitude(new BigDecimal("40.720870"));
        locationOne.setLongitude(new BigDecimal("-73.843354"));

    }
    
    @Test
    public void testGetAddLocations() {

        // Arrange 

        // Act
        locationOne = locationDao.addLocation(locationOne);
        
        Location locationTwo = locationDao.getLocation(locationOne.getId());
        
        // Assert
        assertNotNull(locationOne, "Added location should not be null.");
        assertNotNull(locationTwo, "Retrieved location should not be null.");
        assertEquals(locationOne, locationTwo, "Both locations should be equal.");
        
    }
    
    @Test
    public void testGetLocationBySuperId() {
        
    }

    @Test
    public void testGetAllLocations() {

        locationOne = locationDao.addLocation(locationOne);

        Location locationTwo = new Location();
        locationTwo.setName("Denver");
        locationTwo.setDescription("Mile High City");
        locationTwo.setStreetAddress("1 Nuggets Drive");
        locationTwo.setCity("Denver");
        locationTwo.setState("CO");
        locationTwo.setZip("09856");
        locationTwo.setLatitude(new BigDecimal("40.720870"));
        locationTwo.setLongitude(new BigDecimal("-73.843354"));

        locationTwo = locationDao.addLocation(locationTwo);

        List<Location> locations = locationDao.getAllLocations();

        assertNotNull(locations);
        assertEquals(locations.size(), 2);
        assertTrue(locations.contains(locationOne));
        assertTrue(locations.contains(locationTwo));
    }

    @Test
    public void testDeleteLocation() throws Exception {
        locationOne = locationDao.addLocation(locationOne);

        Location locationTwo = new Location();
        locationTwo.setName("Denver");
        locationTwo.setDescription("Mile High City");
        locationTwo.setStreetAddress("1 Nuggets Drive");
        locationTwo.setCity("Denver");
        locationTwo.setState("CO");
        locationTwo.setZip("09856");
        locationTwo.setLatitude(new BigDecimal("40.720870"));
        locationTwo.setLongitude(new BigDecimal("-73.843354"));

        locationTwo = locationDao.addLocation(locationTwo);

        locationDao.deleteLocation(locationOne.getId());

        List<Location> locations = locationDao.getAllLocations();

        //Assert
        assertNotNull(locations);
        assertEquals(1, locations.size());
        assertTrue(locations.contains(locationTwo));
    }

    @Test
    public void testEditLocation() {

        // Arrange
        locationOne = locationDao.addLocation(locationOne);

        //Act
        locationOne.setZip("93939");
        locationDao.editLocation(locationOne);

        Location locationTwo = locationDao.getLocation(locationOne.getId());

        //Assert
        assertEquals(locationOne, locationTwo);
    }

}

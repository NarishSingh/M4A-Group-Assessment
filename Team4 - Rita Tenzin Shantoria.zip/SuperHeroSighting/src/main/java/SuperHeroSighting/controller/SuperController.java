/*
Created by: Tenzin Woesel
Date created: Sep 27, 2020
Revised by:
Date reised:
 */
package SuperHeroSighting.controller;

import SuperHeroSighting.dao.OrganizationDao;
import SuperHeroSighting.dao.PowerDao;
import SuperHeroSighting.dao.SightingDao;
import SuperHeroSighting.dao.SuperDao;
import SuperHeroSighting.dto.Organization;
import SuperHeroSighting.dto.Power;
import SuperHeroSighting.dto.SuperCharacter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SuperController {

    /*
    Functionality:
        getting all supers
        create, view, edit, and delete supers
        organizations a particular superhero/villain belongs to.
     */
    @Autowired
    SuperDao superDao;

    @Autowired
    PowerDao powerDao;

    @Autowired
    OrganizationDao organizationDao;

    @Autowired
    SightingDao sightingDao;

    Set<ConstraintViolation<SuperCharacter>> violations = new HashSet<>();

    @GetMapping("supercharacters")
    public String displaySuperCharacter(Model model) {
        List<SuperCharacter> superCharacters = superDao.getAllSupers();
        List<Power> powers = powerDao.getAllPowers();
        List<Organization> organizations = organizationDao.getAllOrganizations();
        model.addAttribute("supercharacters", superCharacters);
        model.addAttribute("powers", powers);
        model.addAttribute("organizations", organizations);
        model.addAttribute("errors", violations);
        return "supercharacters";
    }

    @PostMapping("addSuperCharacter")
    public String addSuperCharacter(SuperCharacter superCharacter, HttpServletRequest request) {

        String powerId = request.getParameter("powerId");
        String[] organizationIds = request.getParameterValues("organizationId");

        superCharacter.setPower(powerDao.getPower(Integer.parseInt(powerId)));

        List<Organization> organizations = new ArrayList<>();

        if (organizationIds != null) {
            for (String organizationId : organizationIds) {

                organizations.add(organizationDao.getOrganizationById(Integer.parseInt(organizationId)));
            }
            superCharacter.setOrganizations(organizations);
        } else {
            superCharacter.setOrganizations(null);

        }

        Validator validate = Validation.buildDefaultValidatorFactory().getValidator();
        violations = validate.validate(superCharacter);

        if (violations.isEmpty()) {
            superDao.addSuper(superCharacter);
        }
        return "redirect:/supercharacters";
    }

    @GetMapping("detailSuperCharacter")
    public String superCharacterDetail(Integer id, Model model) {
        SuperCharacter superCharacter = superDao.getSuperById(id);
        model.addAttribute("supercharacter", superCharacter);
        return "detailSuperCharacter";
    }

    @GetMapping("deleteSuperCharacter")
    public String deleteCourse(SuperCharacter superCharacter) {
        superDao.deleteSuper(superCharacter);
        return "redirect:/supercharacters";
    }

    @GetMapping("editSuperCharacter")
    public String performEditSuperCharacter(Integer id, Model model
    ) {
        SuperCharacter superCharacter = superDao.getSuperById(id);
        List<Power> powers = powerDao.getAllPowers();
        List<Organization> organizations = organizationDao.getAllOrganizations();
        model.addAttribute("supercharacter", superCharacter);
        model.addAttribute("powers", powers);
        model.addAttribute("organizations", organizations);
        return "editSuperCharacter";
    }

    @PostMapping("editSuperCharacter")
    public String performEditSuperCharacter(@Valid @ModelAttribute("supercharacter") SuperCharacter superCharacter, BindingResult result, HttpServletRequest request,
            Model model) {

        String powerId = request.getParameter("powerId");
        String[] organizationIds = request.getParameterValues("organizationId");

        superCharacter.setPower(powerDao.getPower(Integer.parseInt(powerId)));

        List<Organization> organizations = new ArrayList<>();

        if (organizationIds != null) {
            for (String organizationId : organizationIds) {
                organizations.add(organizationDao.getOrganizationById(Integer.parseInt(organizationId)));
            }
        }

        superCharacter.setOrganizations(organizations);

        if (result.hasErrors()) {
            model.addAttribute("organizations", organizationDao.getAllOrganizations());
            model.addAttribute("powers", powerDao.getAllPowers());
            model.addAttribute("supercharacter", superCharacter);
            return "editSuperCharacter";
        }

        superDao.editSuper(superCharacter);
        
        return "redirect:/supercharacters";
    }
}

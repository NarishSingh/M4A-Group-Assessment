/*
Created by: Margaret Donin
Date created: 09/27/20
Implemented by:
Date revised:
 */
package SuperHeroSighting.dao;

import SuperHeroSighting.controller.CanNotDeleteForeignKey;
import SuperHeroSighting.dao.LocationDaoDB.LocationMapper;
import SuperHeroSighting.dao.SuperDaoDB.SuperCharacterMapper;
import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.Organization;
import SuperHeroSighting.dto.SuperCharacter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class OrganizationDaoDB implements OrganizationDao {

    @Autowired
    JdbcTemplate jdbc;

    @Override
    @Transactional
    public Organization addOrganization(Organization organization) {

        final String INSERT_ORGANIZATION = "INSERT INTO Organization(name, description, phone, locationId) VALUES (?,?,?,?);";
        jdbc.update(INSERT_ORGANIZATION,
                organization.getName(),
                organization.getDescription(),
                organization.getPhone(),
                organization.getLocation().getId());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID();", Integer.class);
        organization.setId(newId);

        return organization;
    }

    @Override
    @Transactional
    public Organization getOrganizationById(int id) {
        try {
            final String SELECT_ORGANIZATION = "SELECT * "
                    + "FROM Organization "
                    + "WHERE organizationId = ?;";
            Organization organization = jdbc.queryForObject(SELECT_ORGANIZATION, new OrganizationMapper(), id);

            Location location = getLocationForOrganization(organization.getId());
            List<SuperCharacter> supers = getSupersForOrganization(id);

            organization.setLocation(location);
            organization.setSupers(supers);

            return organization;
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Transactional
    @Override
    public List<Organization> getOrganizationBySuperId(int superId) {
        final String SELECT_ALL_ORGANIZATIONS_BY_SUPER = "SELECT o.* "
                + "FROM Organization o "
                + "JOIN SuperOrganization so "
                + "     ON o.organizationId = so.organizationId "
                + "WHERE so.superId = ?;";
        List<Organization> organizations = jdbc.query(SELECT_ALL_ORGANIZATIONS_BY_SUPER, new OrganizationMapper(), superId);
        for (Organization o : organizations) {
            o.setLocation(getLocationForOrganization(o.getId()));
            o.setSupers(getSupersForOrganization(o.getId()));
        }

        return organizations;
    }

    @Transactional
    @Override
    public List<Organization> getAllOrganizations() {
        final String SELECT_ALL_ORGANIZATIONS = "SELECT * FROM Organization;";
        List<Organization> organizations = jdbc.query(SELECT_ALL_ORGANIZATIONS,
                new OrganizationMapper());

        for (Organization o : organizations) {
            o.setSupers(getSupersForOrganization(o.getId()));
            o.setLocation(getLocationForOrganization(o.getId()));
        }

        return organizations;
    }

    @Override
    public void editOrganization(Organization organization) {
        final String EDIT_SIGHTING = "UPDATE Organization "
                + "SET name = ?, description = ?, phone = ?, locationId = ? "
                + "WHERE organizationId = ?;";
        jdbc.update(EDIT_SIGHTING,
                organization.getName(),
                organization.getDescription(),
                organization.getPhone(),
                organization.getLocation().getId(),
                organization.getId());

    }

    @Override
    public void deleteOrganization(Organization organization) throws CanNotDeleteForeignKey {


        final String DELETE_ORGANIZATION_SUPER = "DELETE FROM SuperOrganization WHERE organizationId=?;";
        jdbc.update(DELETE_ORGANIZATION_SUPER, organization.getId());

        final String DELETE_ORGANIZATION = "DELETE FROM Organization "
                + "WHERE organizationId = ?;";
        jdbc.update(DELETE_ORGANIZATION, organization.getId());

    }

    private Location getLocationForOrganization(int organizationId) {
        String SELECT_LOCATION = "SELECT l.* "
                + "FROM Location l "
                + "JOIN Organization o "
                + "     ON l.locationId = o.locationId "
                + "WHERE o.organizationId = ?;";

        return jdbc.queryForObject(SELECT_LOCATION, new LocationMapper(), organizationId);
    }

    private List<SuperCharacter> getSupersForOrganization(int organizationId) {
        String SELECT_SUPERS = "SELECT sc.* "
                + "FROM SuperCharacter sc "
                + "JOIN SuperOrganization so "
                + "     ON sc.superId = so.superId "
                + "WHERE so.organizationId = ?;";
        return jdbc.query(SELECT_SUPERS, new SuperCharacterMapper(), organizationId);
    }

    protected static final class OrganizationMapper implements RowMapper<Organization> {

        @Override
        public Organization mapRow(ResultSet rs, int index) throws SQLException {
            Location location = new Location();
            Organization organization = new Organization();

            organization.setId(rs.getInt("organizationId"));
            organization.setName(rs.getString("name"));
            organization.setDescription(rs.getString("description"));
            organization.setPhone(rs.getString("phone"));

            location.setId(rs.getInt("locationId"));
            organization.setLocation(location);

            return organization;
        }
    }

}

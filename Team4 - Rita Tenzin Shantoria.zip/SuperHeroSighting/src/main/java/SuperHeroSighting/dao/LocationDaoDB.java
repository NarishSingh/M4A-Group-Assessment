/*
Created by: Margaret Donin
Date created: 09/27/20
Implemented by: Shantoria Taylor
Date revised: 09/29/20
 */
package SuperHeroSighting.dao;

import SuperHeroSighting.controller.CanNotDeleteForeignKey;
import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.SuperCharacter;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class LocationDaoDB implements LocationDao {

    @Autowired
    JdbcTemplate jdbc;

    @Override
    @Transactional

    public Location addLocation(Location location) {
        final String INSERT_LOCATION = "INSERT INTO Location (name, description, streetAddress, city, state, zip, latitude, longitude) VALUES (?,?,?,?,?,?,?,?);";
        jdbc.update(INSERT_LOCATION,
                location.getName(),
                location.getDescription(),
                location.getStreetAddress(),
                location.getCity(),
                location.getState(),
                location.getZip(),
                location.getLatitude(),
                location.getLongitude());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID();", Integer.class);
        location.setId(newId);

        return location;
    }

    @Override
    public List<Location> getAllLocations() {
        final String SELECT_ALL_LOCATIONS = "SELECT *  FROM LOCATION;";

        return jdbc.query(SELECT_ALL_LOCATIONS, new LocationMapper());
    }

    @Override
    public Location getLocation(int id) {
        try {
            final String SELECT_LOCATION = "SELECT * FROM LOCATION WHERE locationId = ? ; ";

            Location location = jdbc.queryForObject(SELECT_LOCATION, new LocationMapper(), id);

            return location;
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    public List<Location> getLocationBySuperId(int superId) {
        try {
            final String SELECT_LOCATION_BY_SUPER
                    = "SELECT l.* "
                    + " From Location l "
                    + "JOIN  Sighting s "
                    + "ON s.locationid=l.locationId "
                    + "WHERE  superId= ?";

            List<Location> location = jdbc.query(SELECT_LOCATION_BY_SUPER,
                    new LocationMapper(), superId);

            return location;

        } catch (DataAccessException ex) {

            return null;
        }
    }

    @Override
    public void editLocation(Location location) {
        final String EDIT_LOCATION = "UPDATE Location  "
                + "SET  name = ?, description = ?, streetAddress = ?, city = ?, "
                + "state = ?, zip = ?, latitude = ?, longitude = ? "
                + "WHERE  locationId=?;";

        jdbc.update(EDIT_LOCATION, location.getName(), location.getDescription(),
                location.getStreetAddress(), location.getCity(), location.getState(),
                location.getZip(), location.getLatitude(), location.getLongitude(), location.getId());
    }

    @Override
    public void deleteLocation(Integer locationId) {
        final String DELETE_LOCATION_SUPERORGANIZATION = "DELETE FROM SuperOrganization WHERE superorganization.organizationId = (SELECT o.organizationId FROM Organization o WHERE o.locationId = ?);";
        jdbc.update(DELETE_LOCATION_SUPERORGANIZATION, locationId);
        
        final String DELETE_LOCATION_ORGANIZATION = "DELETE FROM Organization "
                                            + "WHERE locationId = ?;";
        jdbc.update(DELETE_LOCATION_ORGANIZATION, locationId);
        
        final String DELETE_LOCATION_SIGHTING = "DELETE FROM Sighting "
                                            + "WHERE locationId = ?;";
        jdbc.update(DELETE_LOCATION_SIGHTING, locationId);

        final String DELETE_LOCATION = "DELETE FROM LOCATION WHERE locationId=?; ";
        jdbc.update(DELETE_LOCATION, locationId);

    }

    protected static final class LocationMapper implements RowMapper<Location> {

        @Override
        public Location mapRow(ResultSet rs, int index) throws SQLException {

            Location l = new Location();
            l.setId(rs.getInt("locationId"));
            l.setName(rs.getString("name"));
            l.setDescription(rs.getString("description"));
            l.setStreetAddress(rs.getString("streetAddress"));
            l.setCity(rs.getString("city"));
            l.setState(rs.getString("state"));
            l.setZip(rs.getString("zip"));
            
            if (rs.getString("latitude") != null){
                l.setLatitude(new BigDecimal(rs.getString("latitude")));
            }
            
            if (rs.getString("longitude") != null){
                l.setLongitude(new BigDecimal(rs.getString("longitude")));
            }

            return l;
        }
    }
}

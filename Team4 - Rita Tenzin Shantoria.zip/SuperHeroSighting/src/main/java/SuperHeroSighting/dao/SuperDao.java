/*
Created by: Margaret Donin
Date created: 09/26/20
Revised by:
Date revised:
 */
package SuperHeroSighting.dao;

import SuperHeroSighting.dto.SuperCharacter;
import java.util.List;

public interface SuperDao {

    /**
     *
     * @param superCharacter
     * @return
     */
    SuperCharacter addSuper(SuperCharacter superCharacter);

    /**
     *
     * @param superId
     * @return
     */
    SuperCharacter getSuperById(int superId);

    /**
     *
     * @return
     */
    List<SuperCharacter> getAllSupers();

    /**
     * Selects all the supercharacter from the sighting table with the given
     * location id
     *
     * @param locationId
     * @return
     */
    List<SuperCharacter> getSuperByLocationId(int locationId);

    /**
     * Selects every supercharacter from the superorganization table with the
     * given organization id
     *
     * @param organizationId
     * @return
     */
    List<SuperCharacter> getSuperByOrganizationId(int organizationId);

    /**
     *
     * @param superCharacter
     */
    void editSuper(SuperCharacter superCharacter);

    /**
     *
     * @param superCharacter
     */
    void deleteSuper(SuperCharacter superCharacter);
}

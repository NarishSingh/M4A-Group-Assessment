/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SuperHeroSighting.dao;

import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.Organization;
import SuperHeroSighting.dto.Power;
import SuperHeroSighting.dto.SuperCharacter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *
 * @author Tenzin Woesel
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class PowerDaoDBTest {

    @Autowired
    SuperDao superDao;

    @Autowired
    PowerDao powerDao;

    @Autowired
    SightingDao sightingDao;
    
    @Autowired
    LocationDao locationDao;
    
    @Autowired
    OrganizationDao organizationDao;

    public PowerDaoDBTest() {
    }

    @BeforeEach
    public void setUp() {
        List<Power> powers = powerDao.getAllPowers();
        for (Power power : powers) {
            powerDao.deletePowerById(power.getId());
        }
    }

    @Test
    public void testAddAndGetPower() {

        Power power = new Power();
        power.setName("Flame");

        Power addedPower = powerDao.addPower(power);

        Power fromDB = powerDao.getPower(power.getId());

        assertEquals(addedPower, fromDB);

    }

    @Test
    public void testGetAllPowers() {

        Power power = new Power();
        power.setName("Flame");
        power = powerDao.addPower(power);

        Power power1 = new Power();
        power1.setName("Flying");

        power1 = powerDao.addPower(power1);

        List<Power> powers = powerDao.getAllPowers();

        assertEquals(powers.size(), 2);
        assertTrue(powers.contains(power));
        assertTrue(powers.contains(power1));

    }

    @Test
    public void testDeletePower() {

        Location location = new Location();
        location.setName("Atlanta");
        location.setDescription("Hot-lanta");
        location.setStreetAddress("1055 Peach Street");
        location.setCity("Atlanta");
        location.setState("GA");
        location.setZip("35035");
        location.setLatitude(new BigDecimal("40.720870"));
        location.setLongitude(new BigDecimal("-73.843354"));

        location = locationDao.addLocation(location);

        Organization organization = new Organization();
        organization.setName("S.H.I.E.L.D");
        organization.setDescription("Super hero org");
        organization.setPhone("1840123395");
        organization.setLocation(location);

        organization = organizationDao.addOrganization(organization);
        List<Organization> organizationsList = new ArrayList<>();
        organizationsList.add(organization);
        //ARRANGE 
        Power power = new Power();
        power.setName("Flame");
        power = powerDao.addPower(power);

        Power power1 = new Power();
        power1.setName("Flying");

        power1 = powerDao.addPower(power1);
        
        SuperCharacter superOne = new SuperCharacter();
        superOne.setName("Hulk");
        superOne.setDescription("strength.");
        superOne.setPower(power);
        superOne.setOrganizations(organizationsList);
        
        superOne = superDao.addSuper(superOne);

        //ACT
        powerDao.deletePowerById(power.getId());
        
        Power fromDB = powerDao.getPower(power.getId());
        superOne = superDao.getSuperById(superOne.getId());
        System.out.println(fromDB);
        
        List<Power> powers = powerDao.getAllPowers();
        
        //ASSERT
        assertFalse(powers.contains(power));
        assertNull(fromDB);
        assertNull(superOne);

    }

    @Test
    public void testEditPower() {

        //ACT
        //Create the power
        Power power = new Power();
        power.setName("Flame");
        //add to the database
        power = powerDao.addPower(power);

        Power fromDao = powerDao.getPower(power.getId());
        //check if the added power and power from DB is same
        assertEquals(power, fromDao);

        //Change the name of the power
        power.setName("FirePower");
        //ACT
        //Update the power
        powerDao.editPower(power);
        //check if the first added power is same again
        assertNotEquals(power, fromDao);

        //Get the power from the DB after it is updated
        fromDao = powerDao.getPower(power.getId());

        //ASSERT
        assertEquals(power, fromDao);

    }

}

/*
Created by: Margaret Donin
Date created: 09/26/20
Implemented by: Margaret Donin
Date revised: 09/27/20
 */
package SuperHeroSighting.dao;

import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.Sighting;
import SuperHeroSighting.dto.SuperCharacter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class SightingDaoDB implements SightingDao {

    @Autowired
    JdbcTemplate jdbc;

    @Override
    @Transactional
    public Sighting addSighting(Sighting sighting) {
        final String INSERT_SIGHTING = "INSERT INTO Sighting (superId, locationId) "
                + "VALUES(?,?);";
        jdbc.update(INSERT_SIGHTING,
                sighting.getSuperCharacter().getId(),
                sighting.getLocation().getId());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID();", Integer.class);

        final String SELECT_SIGHTING = "SELECT * "
                + "FROM SIGHTING "
                + "WHERE sightingId = ?;";
        sighting = jdbc.queryForObject(SELECT_SIGHTING, new SightingMapper(), newId);
        sighting.setLocation(getLocationForSighting(newId));
        sighting.setSuperCharacter(getSuperForSighting(newId));

        return sighting;
    }

    @Override
    public Sighting getSighting(int id) {
        try {
            final String SELECT_SIGHTING = "SELECT * "
                    + "FROM Sighting "
                    + "WHERE sightingId = ?;";
            Sighting s = jdbc.queryForObject(SELECT_SIGHTING, new SightingMapper(), id);

            s.setLocation(getLocationForSighting(id));
            s.setSuperCharacter(getSuperForSighting(id));

            return s;
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    public List<Sighting> getAllSightings() {
        final String SELECT_ALL_SIGHTINGS = "SELECT * FROM SIGHTING;";
        List<Sighting> sightings = jdbc.query(SELECT_ALL_SIGHTINGS, new SightingMapper());

        for (Sighting s : sightings) {
            int id = s.getId();
            s.setLocation(getLocationForSighting(id));
            s.setSuperCharacter(getSuperForSighting(id));
        }

        return sightings;
    }

    @Override
    public List<Sighting> getSightingByDate(LocalDate ld) {
        try {
            final String SELECT_SIGHTINGS = "SELECT *"
                    + "FROM Sighting "
                    + "WHERE date > ? AND date < ?";

            LocalDateTime ldtOne = LocalDateTime.of(ld.minusDays(1), LocalTime.MAX);
            LocalDateTime ldtTwo = LocalDateTime.of(ld.minusDays(-1), LocalTime.MIDNIGHT);
            Timestamp timeOne = Timestamp.valueOf(ldtOne);
            Timestamp timeTwo = Timestamp.valueOf(ldtTwo);

            List<Sighting> sightings = jdbc.query(SELECT_SIGHTINGS, new SightingMapper(), timeOne, timeTwo);

            for (Sighting s : sightings) {
                int id = s.getId();
                s.setLocation(getLocationForSighting(id));
                s.setSuperCharacter(getSuperForSighting(id));
            }

            return sightings;
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    public List<Sighting> getLastTenSightings() {
        try {
            final String SELECT_SIGHTINGS = "SELECT * "
                    + "FROM Sighting "
                    + "ORDER BY date DESC, sightingId DESC "
                    + "LIMIT 0, 10;";

            List<Sighting> sightings = jdbc.query(SELECT_SIGHTINGS, new SightingMapper());

            for (Sighting s : sightings) {
                int id = s.getId();
                s.setLocation(getLocationForSighting(id));
                s.setSuperCharacter(getSuperForSighting(id));
            }

            return sightings;
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    public void editSighting(Sighting sighting) {
        final String EDIT_SIGHTING = "UPDATE Sighting "
                + "SET superId = ?, locationId = ? "
                + "WHERE sightingId = ?;";
        jdbc.update(EDIT_SIGHTING,
                sighting.getSuperCharacter().getId(),
                sighting.getLocation().getId(),
                sighting.getId());
    }

    @Override
    public void deleteSighting(Sighting sighting) {
        final String DELETE_SIGHTING = "DELETE FROM Sighting "
                + "WHERE sightingId = ?;";
        jdbc.update(DELETE_SIGHTING, sighting.getId());

        try {
            final String DELETE_LOCATION = "DELETE FROM LOCATION "
                    + "WHERE locationId=? ;";
            jdbc.update(DELETE_LOCATION, sighting.getLocation().getId());

        } catch (DataAccessException ex) {
            // do nothing
        }
    }

    private Location getLocationForSighting(int id) {
        final String SELECT_LOCATION = "SELECT l.* "
                + "FROM Location l "
                + "JOIN Sighting s "
                + "     ON s.locationId = l.locationId "
                + "WHERE sightingId = ?;";
        return jdbc.queryForObject(SELECT_LOCATION, new LocationDaoDB.LocationMapper(), id);
    }

    private SuperCharacter getSuperForSighting(int id) {
        final String SELECT_CHARACTER = "SELECT sc.* "
                + "FROM SuperCharacter sc "
                + "JOIN Sighting s "
                + "     ON sc.superId = s.superId "
                + "WHERE sightingId = ?;";
        return jdbc.queryForObject(SELECT_CHARACTER, new SuperDaoDB.SuperCharacterMapper(), id);
    }

    private static final class SightingMapper implements RowMapper<Sighting> {

        @Override
        public Sighting mapRow(ResultSet rs, int index) throws SQLException {
            Sighting s = new Sighting();

            s.setId(rs.getInt("sightingId"));
            s.setDate(rs.getTimestamp("date").toLocalDateTime());

            SuperCharacter superCharacter = new SuperCharacter();
            superCharacter.setId(rs.getInt("superId"));
            s.setSuperCharacter(superCharacter);

            Location location = new Location();
            location.setId(rs.getInt("locationId"));
            s.setLocation(location);

            return s;
        }
    }
}

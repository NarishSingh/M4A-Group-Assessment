/*
Created by: Margaret Donin
Date created: 09/27/20
Revised by:
Date revised:
*/

package SuperHeroSighting.dto;

import java.time.LocalDateTime;
import java.util.Objects;

public class Sighting {
    private int id;
    private LocalDateTime date;
    private SuperCharacter superCharacter;
    private Location location;

    public Sighting() {
    }

    public Sighting(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public SuperCharacter getSuperCharacter() {
        return superCharacter;
    }

    public void setSuperCharacter(SuperCharacter superCharacter) {
        this.superCharacter = superCharacter;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 41 * hash + this.id;
        hash = 41 * hash + Objects.hashCode(this.date);
        hash = 41 * hash + Objects.hashCode(this.superCharacter);
        hash = 41 * hash + Objects.hashCode(this.location);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Sighting other = (Sighting) obj;
        if (this.id != other.id) {
            return false;
        }
        if (!Objects.equals(this.date, other.date)) {
            return false;
        }
        if (!Objects.equals(this.superCharacter, other.superCharacter)) {
            return false;
        }
        if (!Objects.equals(this.location, other.location)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Sighting{" + "id=" + id + ", date=" + date + ", superCharacter="
                + superCharacter + ", location=" + location + '}';
    }

}

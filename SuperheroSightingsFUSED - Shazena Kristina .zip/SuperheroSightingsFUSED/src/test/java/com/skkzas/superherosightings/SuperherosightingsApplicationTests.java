package com.skkzas.superherosightings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperheroSightingsApplicationTests {

	@Test
	void contextLoads() {
	}

}

USE SuperHeroSightings;

-- DESC power;

INSERT INTO power(name)
	VALUES ("One Punch"),
			("Fly"),
            ("Disappear");

-- DESC supercharacter;

INSERT INTO supercharacter(name, description, powerId)
	VALUES ("Hulk", "Green Beast", 1),
			("SuperMan", "Solar beam", 2),
            ("LOKI", "Asgardians", 3);

-- DESC location; 

INSERT INTO location(name, description, streetaddress, city, state, zip, longitude, latitude)
VALUES("something", "Hello form the", "4525", "Woodside", "NY", "11377", -73.843354, 40.720870),
("Hotspot", "Bye form the", "4525", "Woodside", "NY", "11377", -73.843354, 12.009383);

-- DESC organization;

INSERT INTO organization(name, description, phone, locationId)
	VALUES("Avengers", "full of super heroes", "2222222222", 1),
		("Justice League", "full of super heroes", "2222222222", 2);

-- DESC superorganization;

INSERT INTO superorganization(superId, organizationId)
	VALUES(1,2),
		(2,1);
        

 
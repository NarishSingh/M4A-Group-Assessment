/*
Created by: Margaret Donin
Date created: 09/26/20
Revised by:
Date revised:
*/

package SuperHeroSighting.dao;

import SuperHeroSighting.controller.CanNotDeleteForeignKey;
import SuperHeroSighting.dto.Sighting;
import java.time.LocalDate;
import java.util.List;

public interface SightingDao {
    
    /**
     * Takes in a sighting, adds it to the DB.
     * Parameter sighting does not need an id or datetime.
     * Uses the sql method to generate a timestamps.
     * Throws an SQLException if it can not add the sighting.
     * 
     * @param sighting
     * @return sighting with id and timestamp
     */
    Sighting addSighting(Sighting sighting);
    
    /**
     * Returns a sighting by id
     * 
     * @param id
     * @return sighting
     */
    Sighting getSighting(int id);
    
    /**
     * Returns all sightings from the database
     * 
     * @return List of sightings
     */
    List<Sighting> getAllSightings();
    
    /**
     * Returns all sightings from the database that have a specific date
     * 
     * @param ld
     * @return a List of sightings from the selected date
     */
    List<Sighting> getSightingByDate(LocalDate ld);
    
    /**
     * Will not return more than 10.
     * 
     * @return List of the last 10 sightings
     */
    List<Sighting> getLastTenSightings();
    
    /**
     * Edits a sighting entry
     * 
     * @param sighting 
     */
    void editSighting(Sighting sighting);
    
    /**
     * deletes a sighting
     * 
     * @param sighting 
     */
    void deleteSighting(Sighting sighting);
}
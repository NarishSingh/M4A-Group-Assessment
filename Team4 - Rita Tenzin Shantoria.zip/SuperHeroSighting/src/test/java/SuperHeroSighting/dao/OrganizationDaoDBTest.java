package SuperHeroSighting.dao;

import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.Organization;
import SuperHeroSighting.dto.Power;
import SuperHeroSighting.dto.Sighting;
import SuperHeroSighting.dto.SuperCharacter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OrganizationDaoDBTest {

    @Autowired
    private LocationDao locationDao;

    @Autowired
    private OrganizationDao organizationDao;

    @Autowired
    private PowerDao powerDao;

    @Autowired
    private SightingDao sightingDao;

    @Autowired
    private SuperDao superDao;

    private Organization organizationOne;
    private Location location;

    @BeforeEach
    public void setUp() throws Exception {

        List<SuperCharacter> supers = superDao.getAllSupers();

        for (SuperCharacter s : supers) {
            superDao.deleteSuper(s);
        }

        List<Power> powers = powerDao.getAllPowers();

        for (Power p : powers) {
            powerDao.deletePowerById(p.getId());
        }

        List<Sighting> sightings = sightingDao.getAllSightings();

        for (Sighting s : sightings) {
            sightingDao.deleteSighting(s);
        }

        List<Organization> organizations = organizationDao.getAllOrganizations();

        for (Organization o : organizations) {
            organizationDao.deleteOrganization(o);
        }

        List<Location> locations = locationDao.getAllLocations();

        for (Location l : locations) {
            locationDao.deleteLocation(l.getId());
        }

        location = new Location();
        location.setName("New York City");
        location.setDescription("greated city ever");
        location.setStreetAddress("34 Warren Street");
        location.setCity("NYC");
        location.setState("NY");
        location.setZip("10007");
        location.setLatitude(new BigDecimal("40.714460"));
        location.setLongitude(new BigDecimal("-74.008422"));
        location = locationDao.addLocation(location);

        organizationOne = new Organization();
        organizationOne.setName("S.H.I.E.L.D");
        organizationOne.setDescription("Super hero org");
        organizationOne.setPhone("1840123395");
        organizationOne.setLocation(location);
        organizationOne.setSupers(new ArrayList<>());

        organizationOne = organizationDao.addOrganization(organizationOne);
    }

    @Test
    public void testAddOrganization() {

        
        // Act
        Organization organizationTwo = organizationDao.getOrganizationById(organizationOne.getId());

        // Assert
        assertNotNull(organizationOne, "Organization one should not be null.");
        assertNotNull(organizationTwo, "Organization two should not be null.");
        assertEquals(organizationOne, organizationTwo, "Added organization and retreived setting should be the same.");
    }

    @Test
    public void testEditOrganization() {
        // Arrange
        organizationOne.setName("New Name");

        // Act
        organizationDao.editOrganization(organizationOne);
        Organization organizationTwo = organizationDao.getOrganizationById(organizationOne.getId());

        // Assert
        assertEquals(organizationOne, organizationTwo, "Edited should be pulled from the database.");
    }

    @Test
    public void testGetOrganizationBySuperCharacter() {
        // Arrange
        Power power = new Power();
        power.setName("One Punch");
        power = powerDao.addPower(power);

        List<Organization> organizations = organizationDao.getAllOrganizations();

        SuperCharacter superhero = new SuperCharacter();
        superhero.setName("Hulk");
        superhero.setDescription("strength.");
        superhero.setPower(power);
        superhero.setOrganizations(organizations);
        superhero = superDao.addSuper(superhero);
        List<SuperCharacter> supers = new ArrayList<>();
        supers.add(superhero);

        organizationOne.setSupers(supers);

        // Act
        List<Organization> organizationBySuper = organizationDao.getOrganizationBySuperId(superhero.getId());

        // Assert
        assertNotNull(organizationBySuper, "List of supers should not be null.");
        assertEquals(organizationOne.getId(), organizationBySuper.get(0).getId(), "List should contain organizationOne.");

    }

    @Test
    public void testGetAllOrganizations() {
        // Arrange
        Organization organizationTwo = new Organization();
        organizationTwo.setName("Avengers");
        organizationTwo.setDescription("Earth's mightiest heroes");
        organizationTwo.setPhone("2224447777");
        organizationTwo.setLocation(location);
        organizationTwo.setSupers(new ArrayList<SuperCharacter>());
        organizationTwo = organizationDao.addOrganization(organizationTwo);

        // Act
        List<Organization> organizations = organizationDao.getAllOrganizations();

        // Assert
        assertNotNull(organizations, "List should not be null");
        assertEquals(2, organizations.size(), "The list should have two items.");
        assertTrue(organizations.contains(organizationOne), "List should contain organization one.");
        assertTrue(organizations.contains(organizationTwo), "List should contain organization two.");

    }

    @Test
    public void testDeleteOrganization() throws Exception {
        // Arrange

        // Act
        organizationDao.deleteOrganization(organizationOne);
        Organization organizationTwo = organizationDao.getOrganizationById(organizationOne.getId());

        // Assert
        assertNull(organizationTwo, "Organizatin two should be null.");

    }

}

/*
Created by: Margaret Donin
Date created: 09/26/20
Revised by: 
Date revised:
*/

package SuperHeroSighting.dao;

import SuperHeroSighting.dto.Power;
import java.util.List;

public interface PowerDao {
    
    /**
     * 
     * @param power
     * @return 
     */
    Power addPower(Power power);
    
    /**
     * 
     * @param powerId
     * @return 
     */
    Power getPower(int  powerId);
    
    List<Power> getAllPowers();
    
    /**
     * 
     * @param power 
     */
    void editPower(Power power);
    
    /**
     * Deletes the power associated with super
     * Then delete the power
     * 
     * @param powerId 
     */
    void deletePowerById(int powerId);
}
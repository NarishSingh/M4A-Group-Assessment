/*
Created by: Margaret Donin
Date created: 09/29/20
Revised by:
Date revised:
 */
package SuperHeroSighting.dao;

import SuperHeroSighting.dto.Location;
import SuperHeroSighting.dto.Organization;
import SuperHeroSighting.dto.Power;
import SuperHeroSighting.dto.Sighting;
import SuperHeroSighting.dto.SuperCharacter;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SightingDaoDBTest {

    @Autowired
    private LocationDao locationDao;

    @Autowired
    private OrganizationDao organizationDao;

    @Autowired
    private PowerDao powerDao;

    @Autowired
    private SightingDao sightingDao;

    @Autowired
    private SuperDao superDao;

    @Autowired
    JdbcTemplate jdbc;

    private SuperCharacter superOne;
    private Power power;
    private Location location;
    private Sighting sightingOne;
    List<Organization> organizationsList;

    public SightingDaoDBTest() {
    }

    @BeforeEach
    public void setUp() throws Exception {

        List<Power> powers = powerDao.getAllPowers();

        for (Power p : powers) {
            powerDao.deletePowerById(p.getId());
        }

        List<SuperCharacter> supers = superDao.getAllSupers();

        for (SuperCharacter s : supers) {
            superDao.deleteSuper(s);
        }

        List<Sighting> sightings = sightingDao.getAllSightings();

        for (Sighting s : sightings) {
            sightingDao.deleteSighting(s);
        }

        List<Organization> organizations = organizationDao.getAllOrganizations();

        for (Organization o : organizations) {
            organizationDao.deleteOrganization(o);
        }

        List<Location> locations = locationDao.getAllLocations();

        for (Location l : locations) {
            locationDao.deleteLocation(l.getId());
        }

        location = new Location();
        location.setName("Atlanta");
        location.setDescription("Hot-lanta");
        location.setStreetAddress("1055 Peach Street");
        location.setCity("Atlanta");
        location.setState("GA");
        location.setZip("35035");
        location.setLatitude(new BigDecimal("40.720870"));
        location.setLongitude(new BigDecimal("-73.843354"));

        location = locationDao.addLocation(location);

        Organization organization = new Organization();
        organization.setName("S.H.I.E.L.D");
        organization.setDescription("Super hero org");
        organization.setPhone("1840123395");
        organization.setLocation(location);

        organization = organizationDao.addOrganization(organization);
        organizationsList = new ArrayList<>();
        organizationsList.add(organization);
        power = new Power();
        power.setName("One Punch");
        power = powerDao.addPower(power);

        superOne = new SuperCharacter();
        superOne.setName("Hulk");
        superOne.setDescription("strength.");
        superOne.setPower(power);
        superOne.setOrganizations(organizationsList);

        superOne = superDao.addSuper(superOne);

        sightingOne = new Sighting();
        sightingOne.setLocation(location);
        sightingOne.setSuperCharacter(superOne);

    }

    @Test
    public void testAddGetSighting() {
        // Arrange 

        // Act
        sightingOne = sightingDao.addSighting(sightingOne);

        Sighting recievedSighting = sightingDao.getSighting(sightingOne.getId());

        // Assert
        assertEquals(sightingOne, recievedSighting, "Added sighting and retreived setting should be the same.");
    }

    @Test
    public void testGetAllSightings() {
        // Arrange
        Sighting sightingTwo = new Sighting();

        sightingTwo.setLocation(location);
        sightingTwo.setSuperCharacter(superOne);

        // Act
        sightingOne = sightingDao.addSighting(sightingOne);
        sightingTwo = sightingDao.addSighting(sightingTwo);
        List<Sighting> sightings = sightingDao.getAllSightings();

        // Assert
        assertNotNull(sightings, "List should not be null");
        assertEquals(2, sightings.size(), "There should only be two sightings.");
        assertTrue(sightings.contains(sightingOne), "List of sightings should include sightingOne");
        assertTrue(sightings.contains(sightingTwo), "List of sightings should include sightingTwo");
    }

    @Test
    public void testEditSighting() {
        // Arrange
        sightingOne = sightingDao.addSighting(sightingOne);

        Location locationTwo = new Location();
        locationTwo = new Location();
        locationTwo.setName("Home");
        locationTwo.setDescription("not here");
        locationTwo.setStreetAddress("123 Main Street");
        locationTwo.setCity("Brooklyn");
        locationTwo.setState("NY");
        locationTwo.setZip("11235");
        locationTwo.setLatitude(new BigDecimal("40.720870"));
        locationTwo.setLongitude(new BigDecimal("-73.843354"));
        locationTwo = locationDao.addLocation(locationTwo);

        Sighting sightingTwo = sightingDao.getSighting(sightingOne.getId());

        sightingOne.setLocation(locationTwo);

        // Act
        sightingDao.editSighting(sightingOne);

        List<Sighting> sightings = sightingDao.getAllSightings();

        // Assert
        assertNotNull(sightings, "List should not be null.");
        assertEquals(1, sightings.size(), "There should only be one sighting in the list.");
        assertTrue(sightings.contains(sightingOne), "Should contain sighting one.");
        assertFalse(sightings.contains(sightingTwo), "Shoud not contain sighting two.");

    }

    @Test
    public void getSightingByDate() {
        // Arrange
        sightingOne = sightingDao.addSighting(sightingOne);
        Sighting sightingTwo = new Sighting();
        sightingTwo.setLocation(location);
        sightingTwo.setSuperCharacter(superOne);
        sightingTwo = sightingDao.addSighting(sightingTwo);

        LocalDate ld = LocalDate.of(2020, 5, 20);
        LocalTime t = LocalTime.of(10, 3, 30);
        LocalDateTime ldt = LocalDateTime.of(ld, t);

        sightingTwo.setDate(ldt);

        final String EDIT_SIGHTING = "UPDATE Sighting "
                + "SET date = ?, superId = ?, locationId = ? "
                + "WHERE sightingId = ?;";

        jdbc.update(EDIT_SIGHTING,
                Timestamp.valueOf(ldt),
                sightingTwo.getSuperCharacter().getId(),
                sightingTwo.getLocation().getId(),
                sightingTwo.getId());

        // Act
        List<Sighting> sightings = sightingDao.getSightingByDate(ld);

        assertNotNull(sightings, "List should not be null.");
        assertEquals(1, sightings.size(), "There should only be one sighting in the list.");
        assertTrue(sightings.contains(sightingTwo), "Sighting two should be on the list.");
    }

    @Test
    public void testGetLastTenSightings() {
        // Arrange and Act
        sightingOne = sightingDao.addSighting(sightingOne);

        Sighting[] sightings = new Sighting[10];

        for (int i = 0; i < 10; i++) {
            Sighting sighting = new Sighting();
            sighting.setLocation(location);
            sighting.setSuperCharacter(superOne);

            sightings[i] = sightingDao.addSighting(sighting);
        }

        List<Sighting> retrievedSightings = sightingDao.getLastTenSightings();

        // Assert
        assertNotNull(sightings, "List of sightings should not be null.");
        assertEquals(10, retrievedSightings.size(), "Should only have ten sightings.");
        assertTrue(retrievedSightings.contains(sightings[9]), "Should contain the last sighting put in.");
        assertFalse(retrievedSightings.contains(sightingOne), "Should not contain sighting one.");

    }

    @Test
    public void testDeleteSighting() throws Exception {
        // Arrange
        // ... do nothing

        // Act
        sightingOne = sightingDao.addSighting(sightingOne);
        sightingDao.deleteSighting(sightingOne);
        Sighting retrievedSighting = sightingDao.getSighting(sightingOne.getId());

        // Assert
        assertNull(retrievedSighting, "Sighting should be null.");

    }

}

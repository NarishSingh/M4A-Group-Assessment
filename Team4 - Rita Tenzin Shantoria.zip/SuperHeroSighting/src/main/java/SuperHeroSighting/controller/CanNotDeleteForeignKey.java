/*
Created by: Margaret Donin
Date created: 10/05/20
Date revised:
*/

package SuperHeroSighting.controller;

public class CanNotDeleteForeignKey extends Exception{

}

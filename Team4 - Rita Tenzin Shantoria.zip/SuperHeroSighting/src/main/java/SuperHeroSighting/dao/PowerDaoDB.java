/*
Created by: Margaret Donin
Date created: 09/26/20
Implemented by: 
Date revised:
 */
package SuperHeroSighting.dao;

import SuperHeroSighting.dao.SuperDaoDB.SuperCharacterMapper;
import SuperHeroSighting.dto.Power;
import SuperHeroSighting.dto.SuperCharacter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class PowerDaoDB implements PowerDao {

    @Autowired
    JdbcTemplate jdbc;

    @Autowired
    SuperDao superDao;

    //CRUD
    @Override
    @Transactional
    public Power addPower(Power power) {
        final String INSERT_POWER = "INSERT INTO Power (name) VALUES(?)";
        jdbc.update(INSERT_POWER,
                power.getName());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        power.setId(newId);

        return power;
    }

    @Override
    public Power getPower(int powerId) {
        try {
            final String SELECT_POWER_BY_NAME = "SELECT * "
                    + "FROM power "
                    + "WHERE powerId = ?";
            Power power = jdbc.queryForObject(SELECT_POWER_BY_NAME, new PowerMapper(), powerId);
            power.setId(powerId);
            return power;
        } catch (DataAccessException ex) {
            return null;
        }

    }

    @Override
    public List<Power> getAllPowers() {
        final String SELECT_ALL_POWER = "SELECT * FROM Power;";
        List<Power> powers = jdbc.query(SELECT_ALL_POWER, new PowerMapper());

        return powers;
    }

    @Override
    public void editPower(Power power) {
        final String UPDATE_POWER = "UPDATE Power SET name= ? "
                + "WHERE powerId=?";
        jdbc.update(UPDATE_POWER, power.getName(), power.getId());
    }

    @Override
    @Transactional
    public void deletePowerById(int powerId) {

        final String SELECT_SUPER_BY_POWER = "SELECT * FROM SuperCharacter WHERE powerId = ?;";
        List<SuperCharacter> superCharacters = jdbc.query(SELECT_SUPER_BY_POWER, new SuperCharacterMapper(), powerId);

        for (SuperCharacter superCharacter : superCharacters) {
            int superId = superCharacter.getId();

            final String DELETE_SUPER_SIGHTING = "DELETE FROM SIGHTING WHERE superId = ?;";
            jdbc.update(DELETE_SUPER_SIGHTING, superId);

            final String DELETE_SUPER_Organization = "DELETE FROM SuperOrganization WHERE superId = ?;";
            jdbc.update(DELETE_SUPER_Organization, superId);

            final String DELETE_SUPER = "DELETE FROM SuperCharacter WHERE superId = ?;";
            jdbc.update(DELETE_SUPER, superId);

        }

        final String DELETE_POWER_BY_ID = "DELETE FROM Power WHERE powerId = ?;";
        jdbc.update(DELETE_POWER_BY_ID, powerId);
    }

    protected static final class PowerMapper implements RowMapper<Power> {

        @Override
        public Power mapRow(ResultSet rs, int index) throws SQLException {
            Power power = new Power();
            power.setId(rs.getInt("powerId"));
            power.setName(rs.getString("name"));
            return power;
        }
    }
}

-- Created by: Tenzin Woesel
-- Date created: 09/22/20
-- Date revised: 09/23/20: Margaret Donin, making sure it follows convention

DROP DATABASE IF EXISTS superherosightingsTest;
CREATE DATABASE SuperHeroSightingsTest;

USE SuperHeroSightingsTest;

CREATE TABLE `Power`(
	`powerId` INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	`name` 	  VARCHAR(45) NOT NULL 
);

CREATE TABLE `SuperCharacter`(
	`superId`		INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	`name`			VARCHAR(45) NOT NULL,
	`description`	VARCHAR(100) NOT NULL,
    `powerId`		INT NOT NULL,
    FOREIGN KEY `fk_SuperCharacter_Power`(`powerId`) REFERENCES `Power`(`powerId`)
);

CREATE TABLE `Location`(
	`locationId`    INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	`name`			VARCHAR(45) NOT NULL,
	`description`	VARCHAR(45) NOT NULL,
	`streetAddress` VARCHAR(45) NOT NULL,
	`city`          VARCHAR(45) NOT NULL,
	`state`         CHAR(2) NOT NULL,
	`zip`           CHAR(5) NOT NULL,
	`latitude`      DECIMAL(8,6) NOT NULL,
	`longitude`     DECIMAL(9,6) NOT NULL 
);

CREATE TABLE `Sighting`(
    `sightingId` INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    `date`       DATETIME NOT NULL DEFAULT NOW(),
    `superId`    INT NOT NULL,
    `locationId` INT NOT NULL,

    FOREIGN KEY `fk_Sighting_SuperCharacter` (`superId`) REFERENCES `SuperCharacter` (`superId`),
    FOREIGN KEY `fk_Sighting_Location` (`locationId`) REFERENCES `Location` (`locationId`)
);

CREATE TABLE `Organization`(
    `organizationId`	INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    `name`				VARCHAR(45) NOT NULL,
    `description`		VARCHAR(100) NOT NULL,
    `phone`				CHAR(10) NOT NULL,
    `locationId`		INT NOT NULL,
    
    FOREIGN KEY fk_Organization_Location (locationId)
        REFERENCES Location (locationId)
);

CREATE TABLE `SuperOrganization`(
    `superId`			INT NOT NULL,
    `organizationId`	INT NOT NULL,
    PRIMARY KEY (`superId`, `organizationId`),

    FOREIGN KEY `fk_SuperOrganization_SuperCharacter` (`superId`) REFERENCES `SuperCharacter` (`superId`),
    FOREIGN KEY `fk_SuperOrganization_Organization` (`organizationId`) REFERENCES `Organization` (`organizationId`)
);
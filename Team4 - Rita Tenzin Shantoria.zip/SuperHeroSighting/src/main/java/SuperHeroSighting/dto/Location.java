/*
Created by: Margaret Donin
Date created: 09/27/20
Revised by:
Date revised:
*/

package SuperHeroSighting.dto;

import java.math.BigDecimal;
import java.util.Objects;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class Location {
    private int id;
    
    @NotBlank(message = "You must have a name for the location.")
    @Size(max = 45, message= "Name has to be 45 characters or less. ")
    private String name;
    
    @NotBlank(message= "You must have a description.")
    @Size(max=45, message= "The description must be 45 characters or less.")
    private String description;
    
    @NotBlank(message= "You must have a street address.")
    @Size(max=45, message= "The street address must be 45 characters or less.")
    private String streetAddress;
    
    @NotBlank(message= "You must enter a city.")
    @Size(max=45, message= "The city must be 45 characters or less.")
    private String city;
    
    @NotBlank(message= "You must have a state.")
    @Size(max=2, message= "Please use the state abbreviation (ex. NY or CA).")
    private String state;
    
    @Size(max=5, message="The zip code should be 5 numbers.")
    private String zip;

    @DecimalMax(value = "90", inclusive = true)
    @DecimalMin(value = "-90", inclusive = true)
    private BigDecimal latitude;
    
    @DecimalMax(value = "180", inclusive = false)
    @DecimalMin(value = "-180", inclusive = false)
    private BigDecimal longitude;

    public Location() {
    }

    public Location(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.id;
        hash = 79 * hash + Objects.hashCode(this.name);
        hash = 79 * hash + Objects.hashCode(this.description);
        hash = 79 * hash + Objects.hashCode(this.streetAddress);
        hash = 79 * hash + Objects.hashCode(this.city);
        hash = 79 * hash + Objects.hashCode(this.state);
        hash = 79 * hash + Objects.hashCode(this.zip);
        hash = 79 * hash + Objects.hashCode(this.latitude);
        hash = 79 * hash + Objects.hashCode(this.longitude);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Location other = (Location) obj;
        if (this.id != other.id) {
            return false;
        }
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.description, other.description)) {
            return false;
        }
        if (!Objects.equals(this.streetAddress, other.streetAddress)) {
            return false;
        }
        if (!Objects.equals(this.city, other.city)) {
            return false;
        }
        if (!Objects.equals(this.state, other.state)) {
            return false;
        }
        if (!Objects.equals(this.zip, other.zip)) {
            return false;
        }
        if (!Objects.equals(this.latitude, other.latitude)) {
            return false;
        }
        if (!Objects.equals(this.longitude, other.longitude)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Location{" + "id=" + id + ", name=" + name + ", description="
                + description + ", streetAddress=" + streetAddress + ", city=" + city
                + ", state=" + state + ", zip=" + zip + ", latitude=" + latitude
                + ", longitude=" + longitude + '}';
    }
    
}

/*
Created by: 
Date created:
Date revised:
 */
package SuperHeroSighting.controller;

import SuperHeroSighting.dao.LocationDao;
import SuperHeroSighting.dao.SightingDao;
import SuperHeroSighting.dao.SuperDao;
import SuperHeroSighting.dto.Location;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LocationController {

    @Autowired
    private LocationDao locationDao;

    @Autowired
    private SightingDao sightingDao;

    @Autowired
    private SuperDao superDao;

    @GetMapping("locations")
    public String displayLocations(Model model) {
        List<Location> locations = locationDao.getAllLocations();
        model.addAttribute("locations", locations);
        violations.clear();
        model.addAttribute("errors", violations);
        return "locations";
    }

    Set<ConstraintViolation<Location>> violations = new HashSet<>();

    @PostMapping("addLocation")
    public String addLocation(Location location, HttpServletRequest request) {

        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String streetAddress = request.getParameter("streetAddress");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String zip = request.getParameter("zip");
        String latitude = request.getParameter("latitude");
        String longitude = request.getParameter("longitude");

        location.setName(name);
        location.setDescription(description);
        location.setStreetAddress(streetAddress);
        location.setCity(city);
        location.setState(state);
        location.setZip(zip);

        try {
            location.setLatitude(new BigDecimal(latitude));
        } catch (NumberFormatException ex) {
            // do nothing.
        }

        try {
            location.setLongitude(new BigDecimal(longitude));
        } catch (NumberFormatException ex) {
            // do nothing.
        }

        Validator validate = Validation.buildDefaultValidatorFactory().getValidator();
        violations = validate.validate(location);

        if (violations.isEmpty()) {
            locationDao.addLocation(location);
        } else {
            //add the locations
            //add the violations
            return "locations";
        }

        return "redirect:/locations";

    }

    @GetMapping("locationDetail")
    public String locationDetail(Integer id, Model model) {
        Location location = locationDao.getLocation(id);
        model.addAttribute("location", location);
        return "locationDetail";

    }

    @GetMapping("editLocation")
    public String editLocation(Integer id, Model model) {
        Location location = locationDao.getLocation(id);
        model.addAttribute("location", location);

        return "editLocation";
    }

    @PostMapping("editLocation")
    public String editLocation(@Valid Location location, BindingResult result) {

        {
            if (result.hasErrors()) {
                return "editLocation";
            }

            locationDao.editLocation(location);
            return "redirect:/locations";
        }
    }

    @GetMapping("deleteLocation")
    public String deleteLocation(Integer id) {
        locationDao.deleteLocation(id);
        return "redirect:/locations";

    }

    @GetMapping("locationBySuperId")
    public String locationBySuperId(Integer superId, Model model) {

        List<Location> locations = locationDao.getLocationBySuperId(superId);
        model.addAttribute("locations", locations);
        return "locations";
    }

}
